Changelog
=========

Development version
-------------------

Version 0.5.0 (August 8, 2022)
------------------------------

New features and improvements:

- Testing suite overhaul

Bug fixes:

- Delta metrics
