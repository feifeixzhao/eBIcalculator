.. _rivers:

========
rivers
========

.. automodule:: rivgraph.rivers.river_directionality
   :members:
   :special-members:

.. automodule:: rivgraph.rivers.river_utils
   :members:
   :special-members:
