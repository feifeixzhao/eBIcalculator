.. _apiref:

=============
API Reference
=============

.. toctree::
   :maxdepth: 3
   :caption: Module Contents:

   rivgraph
   deltas
   rivers 
