.. _deltas:

========
deltas
========

.. automodule:: rivgraph.deltas.delta_directionality
   :members:
   :special-members:

.. automodule:: rivgraph.deltas.delta_metrics
   :members:
   :special-members:

.. automodule:: rivgraph.deltas.delta_utils
   :members:
   :special-members: