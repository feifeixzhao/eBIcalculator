RivGraph in the wild
====================

Some selected publications that have used RivGraph to answer some cool science questions.

`Let us know <https://github.com/VeinsOfTheEarth/RivGraph/issues>`_ if you'd like to add an application to the gallery!

